---
title: "My Guide to SF"
date: 2021-02-04T08:06:25+06:00
description: I have listed few commonly used GIT commands for quick referencing.
hero: /images/sections/posts/SF_FOG.png
author:
  name: Aswin Natesh
  image: /images/author/aswinnateshv21.png

menu:
  sidebar:
    name: SF Travel Tips2
    identifier: SF
    weight: 1
---


## Blockquotes

> Site in preparation. Sorry for the Inconvenience

{{< youtube id="SDh99jGzCc4" autoplay="true" title="A New Hugo Site in Under Two Minutes" >}}